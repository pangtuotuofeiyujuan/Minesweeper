export type Difficulty = 'beginner' | 'intermediate' | 'expert';

export type GameStatus = 'idle' | 'playing' | 'won' | 'lost';

export interface Cell {
  row: number;
  col: number;
  isMine: boolean;
  isRevealed: boolean;
  isFlagged: boolean;
  adjacentMines: number;
}

export interface GameConfig {
  rows: number;
  cols: number;
  mines: number;
}

export const DIFFICULTY_CONFIG: Record<Difficulty, GameConfig> = {
  beginner: { rows: 9, cols: 9, mines: 10 },
  intermediate: { rows: 16, cols: 16, mines: 40 },
  expert: { rows: 16, cols: 30, mines: 99 },
};

export function createEmptyBoard(rows: number, cols: number): Cell[][] {
  const board: Cell[][] = [];
  for (let row = 0; row < rows; row++) {
    board[row] = [];
    for (let col = 0; col < cols; col++) {
      board[row][col] = {
        row,
        col,
        isMine: false,
        isRevealed: false,
        isFlagged: false,
        adjacentMines: 0,
      };
    }
  }
  return board;
}

export function placeMines(
  board: Cell[][],
  mineCount: number,
  excludeRow: number,
  excludeCol: number
): Cell[][] {
  const rows = board.length;
  const cols = board[0].length;
  const newBoard = board.map(row => row.map(cell => ({ ...cell })));
  let placedMines = 0;

  while (placedMines < mineCount) {
    const row = Math.floor(Math.random() * rows);
    const col = Math.floor(Math.random() * cols);

    if (
      !newBoard[row][col].isMine &&
      (row !== excludeRow || col !== excludeCol) &&
      Math.abs(row - excludeRow) > 1 &&
      Math.abs(col - excludeCol) > 1
    ) {
      newBoard[row][col].isMine = true;
      placedMines++;
    }
  }

  return newBoard;
}

export function calculateAdjacentMines(board: Cell[][]): Cell[][] {
  const rows = board.length;
  const cols = board[0].length;
  const newBoard = board.map(row => row.map(cell => ({ ...cell })));

  for (let row = 0; row < rows; row++) {
    for (let col = 0; col < cols; col++) {
      if (newBoard[row][col].isMine) continue;

      let count = 0;
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          const newRow = row + dr;
          const newCol = col + dc;
          if (
            newRow >= 0 &&
            newRow < rows &&
            newCol >= 0 &&
            newCol < cols &&
            newBoard[newRow][newCol].isMine
          ) {
            count++;
          }
        }
      }
      newBoard[row][col].adjacentMines = count;
    }
  }

  return newBoard;
}

export function revealCell(board: Cell[][], row: number, col: number): Cell[][] {
  const rows = board.length;
  const cols = board[0].length;
  const newBoard = board.map(r => r.map(cell => ({ ...cell })));

  function reveal(r: number, c: number) {
    if (
      r < 0 ||
      r >= rows ||
      c < 0 ||
      c >= cols ||
      newBoard[r][c].isRevealed ||
      newBoard[r][c].isFlagged
    ) {
      return;
    }

    newBoard[r][c].isRevealed = true;

    if (newBoard[r][c].adjacentMines === 0 && !newBoard[r][c].isMine) {
      for (let dr = -1; dr <= 1; dr++) {
        for (let dc = -1; dc <= 1; dc++) {
          if (dr === 0 && dc === 0) continue;
          reveal(r + dr, c + dc);
        }
      }
    }
  }

  reveal(row, col);
  return newBoard;
}

export function toggleFlag(board: Cell[][], row: number, col: number): Cell[][] {
  const newBoard = board.map(r => r.map(cell => ({ ...cell })));
  if (!newBoard[row][col].isRevealed) {
    newBoard[row][col].isFlagged = !newBoard[row][col].isFlagged;
  }
  return newBoard;
}

export function checkWin(board: Cell[][], mineCount: number): boolean {
  let revealedCount = 0;
  let totalCells = 0;

  for (const row of board) {
    for (const cell of row) {
      totalCells++;
      if (cell.isRevealed) {
        revealedCount++;
      }
    }
  }

  return revealedCount === totalCells - mineCount;
}

export function countFlags(board: Cell[][]): number {
  let count = 0;
  for (const row of board) {
    for (const cell of row) {
      if (cell.isFlagged) {
        count++;
      }
    }
  }
  return count;
}

export function revealAllMines(board: Cell[][]): Cell[][] {
  return board.map(row =>
    row.map(cell => ({
      ...cell,
      isRevealed: cell.isMine ? true : cell.isRevealed,
    }))
  );
}