interface GameOverModalProps {
  isOpen: boolean;
  isWin: boolean;
  onRestart: () => void;
}

export function GameOverModal({ isOpen, isWin, onRestart }: GameOverModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 animate-fade-in">
      <div className="bg-white rounded-2xl p-8 shadow-2xl transform animate-bounce-in text-center">
        <div className="text-6xl mb-4">{isWin ? '🎉' : '💥'}</div>
        <h2 className={`text-3xl font-bold mb-2 ${isWin ? 'text-green-600' : 'text-red-600'}`}>
          {isWin ? '恭喜你赢了！' : '游戏结束！'}
        </h2>
        <p className="text-gray-600 mb-6">
          {isWin ? '你成功揭开了所有安全格子！' : '很遗憾，你踩到了地雷。'}
        </p>
        <button
          onClick={onRestart}
          className="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-8 rounded-full text-lg transition-all duration-200 hover:scale-105 active:scale-95 shadow-lg"
        >
          🔄 再玩一次
        </button>
      </div>
    </div>
  );
}