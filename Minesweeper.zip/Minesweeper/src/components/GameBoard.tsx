import { Cell } from './Cell';
import { Cell as CellType, GameStatus } from '../utils/gameUtils';

interface GameBoardProps {
  board: CellType[][];
  status: GameStatus;
  onCellClick: (row: number, col: number) => void;
  onRightClick: (row: number, col: number) => void;
}

export function GameBoard({ board, status, onCellClick, onRightClick }: GameBoardProps) {
  const gameOver = status === 'won' || status === 'lost';
  const cols = board[0]?.length || 0;

  return (
    <div className="overflow-x-auto w-full max-w-full">
      <div className="inline-block p-2 bg-gray-500 rounded shadow-lg">
        <div
          className="grid gap-0"
          style={{
            gridTemplateColumns: `repeat(${cols}, minmax(0, 1fr))`,
            gridAutoRows: '32px',
          }}
        >
          {board.map((row, rowIndex) =>
            row.map((cell, colIndex) => (
              <Cell
                key={`${rowIndex}-${colIndex}`}
                cell={cell}
                onClick={() => onCellClick(rowIndex, colIndex)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  onRightClick(rowIndex, colIndex);
                }}
                gameOver={gameOver}
              />
            ))
          )}
        </div>
      </div>
    </div>
  );
}