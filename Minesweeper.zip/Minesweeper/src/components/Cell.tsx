import { Cell as CellType } from '../utils/gameUtils';

interface CellProps {
  cell: CellType;
  onClick: () => void;
  onContextMenu: (e: React.MouseEvent) => void;
  gameOver: boolean;
}

const NUMBER_COLORS: Record<number, string> = {
  1: 'text-blue-600',
  2: 'text-green-600',
  3: 'text-red-600',
  4: 'text-purple-800',
  5: 'text-amber-800',
  6: 'text-cyan-600',
  7: 'text-black',
  8: 'text-gray-600',
};

export function Cell({ cell, onClick, onContextMenu, gameOver }: CellProps) {
  const { isRevealed, isFlagged, isMine, adjacentMines } = cell;

  const getCellContent = () => {
    if (isFlagged && !isRevealed) {
      return '🚩';
    }
    if (!isRevealed) {
      return null;
    }
    if (isMine) {
      return '💣';
    }
    if (adjacentMines > 0) {
      return adjacentMines;
    }
    return null;
  };

  const getCellClasses = () => {
    const base =
      'w-8 h-8 flex items-center justify-center text-sm font-bold cursor-pointer select-none transition-all duration-100 border';

    if (isRevealed) {
      if (isMine) {
        return `${base} bg-red-400 border-red-500`;
      }
      return `${base} bg-gray-200 border-gray-300`;
    }

    return `${base} bg-gradient-to-br from-gray-300 to-gray-400 border-gray-500 shadow-[inset_2px_2px_0_#fff,inset_-2px_-2px_0_#999] hover:from-gray-200 hover:to-gray-300 active:shadow-none active:bg-gray-300`;
  };

  return (
    <button
      className={getCellClasses()}
      onClick={onClick}
      onContextMenu={onContextMenu}
      disabled={gameOver && !isMine}
    >
      <span className={isRevealed && adjacentMines > 0 ? NUMBER_COLORS[adjacentMines] : ''}>
        {getCellContent()}
      </span>
    </button>
  );
}