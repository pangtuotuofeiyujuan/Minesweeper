import { Difficulty } from '../utils/gameUtils';

interface DifficultySelectorProps {
  currentDifficulty: Difficulty;
  onDifficultyChange: (difficulty: Difficulty) => void;
}

const DIFFICULTY_LABELS: Record<Difficulty, string> = {
  beginner: '初级',
  intermediate: '中级',
  expert: '高级',
};

export function DifficultySelector({ currentDifficulty, onDifficultyChange }: DifficultySelectorProps) {
  return (
    <div className="flex gap-2">
      {(Object.keys(DIFFICULTY_LABELS) as Difficulty[]).map((diff) => (
        <button
          key={diff}
          onClick={() => onDifficultyChange(diff)}
          className={`px-4 py-2 rounded-lg font-medium transition-all duration-200 ${
            currentDifficulty === diff
              ? 'bg-blue-600 text-white shadow-lg scale-105'
              : 'bg-gray-200 text-gray-700 hover:bg-gray-300'
          }`}
        >
          {DIFFICULTY_LABELS[diff]}
        </button>
      ))}
    </div>
  );
}