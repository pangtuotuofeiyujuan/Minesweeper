interface StatusBarProps {
  remainingMines: number;
  timeElapsed: number;
  onRestart: () => void;
  status: 'idle' | 'playing' | 'won' | 'lost';
}

export function StatusBar({ remainingMines, timeElapsed, onRestart, status }: StatusBarProps) {
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const getEmoji = () => {
    switch (status) {
      case 'won':
        return '😎';
      case 'lost':
        return '😵';
      default:
        return '🙂';
    }
  };

  return (
    <div className="flex items-center justify-between w-full max-w-md bg-gray-300 p-3 rounded-lg shadow-inner">
      <div className="flex items-center gap-2 bg-black text-red-500 px-3 py-2 rounded font-mono text-xl min-w-[80px]">
        <span>🚩</span>
        <span>{remainingMines.toString().padStart(3, '0')}</span>
      </div>

      <button
        onClick={onRestart}
        className="text-3xl hover:scale-110 transition-transform cursor-pointer active:scale-95"
        title="重新开始"
      >
        {getEmoji()}
      </button>

      <div className="flex items-center gap-2 bg-black text-red-500 px-3 py-2 rounded font-mono text-xl min-w-[80px] justify-end">
        <span>⏱️</span>
        <span>{formatTime(timeElapsed)}</span>
      </div>
    </div>
  );
}