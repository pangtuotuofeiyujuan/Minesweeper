import { GameBoard } from './components/GameBoard';
import { StatusBar } from './components/StatusBar';
import { DifficultySelector } from './components/DifficultySelector';
import { GameOverModal } from './components/GameOverModal';
import { useGame } from './hooks/useGame';

export default function App() {
  const {
    board,
    status,
    timeElapsed,
    remainingMines,
    difficulty,
    handleCellClick,
    handleRightClick,
    resetGame,
    handleDifficultyChange,
  } = useGame();

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-100 to-purple-100 flex flex-col items-center justify-center p-4">
      <h1 className="text-4xl font-bold text-gray-800 mb-6 flex items-center gap-3">
        <span>💣</span>
        <span>扫雷游戏</span>
        <span>💣</span>
      </h1>

      <div className="mb-6">
        <DifficultySelector
          currentDifficulty={difficulty}
          onDifficultyChange={handleDifficultyChange}
        />
      </div>

      <div className="mb-4">
        <StatusBar
          remainingMines={remainingMines}
          timeElapsed={timeElapsed}
          onRestart={resetGame}
          status={status}
        />
      </div>

      <GameBoard
        board={board}
        status={status}
        onCellClick={handleCellClick}
        onRightClick={handleRightClick}
      />

      <div className="mt-6 text-gray-600 text-sm text-center">
        <p>🖱️ 左键点击揭开格子 | 🖱️ 右键点击标记/取消红旗</p>
        <p className="mt-1">点击空白格会自动展开周围区域</p>
      </div>

      <GameOverModal
        isOpen={status === 'won' || status === 'lost'}
        isWin={status === 'won'}
        onRestart={resetGame}
      />
    </div>
  );
}