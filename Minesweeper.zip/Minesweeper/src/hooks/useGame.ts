import { useState, useEffect, useCallback } from 'react';
import {
  Cell,
  Difficulty,
  GameStatus,
  DIFFICULTY_CONFIG,
  createEmptyBoard,
  placeMines,
  calculateAdjacentMines,
  revealCell,
  toggleFlag,
  checkWin,
  countFlags,
  revealAllMines,
} from '../utils/gameUtils';

export function useGame() {
  const [difficulty, setDifficulty] = useState<Difficulty>('beginner');
  const [board, setBoard] = useState<Cell[][]>([]);
  const [status, setStatus] = useState<GameStatus>('idle');
  const [timeElapsed, setTimeElapsed] = useState(0);
  const [isFirstClick, setIsFirstClick] = useState(true);

  const config = DIFFICULTY_CONFIG[difficulty];
  const flagsUsed = countFlags(board);
  const remainingMines = config.mines - flagsUsed;

  useEffect(() => {
    resetGame();
  }, [difficulty]);

  useEffect(() => {
    let timer: ReturnType<typeof setInterval>;
    if (status === 'playing') {
      timer = setInterval(() => {
        setTimeElapsed(prev => prev + 1);
      }, 1000);
    }
    return () => clearInterval(timer);
  }, [status]);

  const resetGame = useCallback(() => {
    const newBoard = createEmptyBoard(config.rows, config.cols);
    setBoard(newBoard);
    setStatus('idle');
    setTimeElapsed(0);
    setIsFirstClick(true);
  }, [config.rows, config.cols]);

  const handleCellClick = useCallback(
    (row: number, col: number) => {
      if (status === 'won' || status === 'lost') return;
      if (board[row][col].isRevealed || board[row][col].isFlagged) return;

      let currentBoard = board;

      if (isFirstClick) {
        const boardWithMines = placeMines(currentBoard, config.mines, row, col);
        currentBoard = calculateAdjacentMines(boardWithMines);
        setIsFirstClick(false);
        setStatus('playing');
      }

      if (currentBoard[row][col].isMine) {
        const finalBoard = revealAllMines(currentBoard);
        setBoard(finalBoard);
        setStatus('lost');
        return;
      }

      const newBoard = revealCell(currentBoard, row, col);
      setBoard(newBoard);

      if (checkWin(newBoard, config.mines)) {
        setStatus('won');
      }
    },
    [board, status, isFirstClick, config.mines]
  );

  const handleRightClick = useCallback(
    (row: number, col: number) => {
      if (status === 'won' || status === 'lost') return;
      if (board[row][col].isRevealed) return;

      if (status === 'idle') {
        setStatus('playing');
      }

      const newBoard = toggleFlag(board, row, col);
      setBoard(newBoard);
    },
    [board, status]
  );

  const handleDifficultyChange = useCallback((newDifficulty: Difficulty) => {
    setDifficulty(newDifficulty);
  }, []);

  return {
    board,
    status,
    timeElapsed,
    remainingMines,
    difficulty,
    config,
    handleCellClick,
    handleRightClick,
    resetGame,
    handleDifficultyChange,
  };
}